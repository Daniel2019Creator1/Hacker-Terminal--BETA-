# Hacker-Terminal(BETA)
its a term..
<!--

Hacker Terminal

The terminal should be able to execute the following commands:
- list
- connect
- engage

list
Lists all the supported commands.

connect
Shows a fancy progress bar that imitates connecting to a remote server (only UI).

engage
Transforms the terminal into a Matrix-inspired display where symbols are raining from the top of the screen in different colors.

Feel free to add other commands to make your terminal more interactive and fun!

ref: https://www.sololearn.com/learn/9603/?ref=app

-->
